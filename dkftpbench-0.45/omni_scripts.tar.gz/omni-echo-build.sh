#!/bin/sh

# Creates an echo directory and copies the needed source
# from /opt/omniorb3/native/src/examples/echo.
# Copies Makefile.echo into echo/Makefile and builds the echo example
#
# Takes a single argument, which is either "native" or "cross"

if [ $# -ne 1 ]; then
    echo "Usage: $0 {native|cross}"
    exit 1
fi

TYPE=$1
case $TYPE in
    native) ECHODIR=echo ;;
    cross)  ECHODIR=echo-405 ;;
    *) echo "Error: argument must be either native or cross."
       exit 1 ;;
esac

set -xe

OMNIBASE=/opt/omniorb3/native
ORIGDIR=`pwd`

if [ -e "$ECHODIR" ]; then
    rm -rf $ECHODIR
    #echo "echo already exists in current directory.  Aborting."
    #exit 1
fi

mkdir $ECHODIR
cp Makefile.echo $ECHODIR/Makefile

cd $OMNIBASE/src/examples/echo
cp "echo.idl" eg2_impl.cc eg2_clt.cc echoexamples.module "$ORIGDIR/$ECHODIR"

cd $ORIGDIR/$ECHODIR

case $TYPE in
    native) make
	;;
    cross) make TARGETPLAT=405_linux_2.0_glibc2.1 CROSS_CFLAGS=-mcpu=403 \
	    CROSS_TOOL_PREFIX=/opt/hardhat/devkit/ppc/405/bin/powerpc-linux-
	;;
esac
