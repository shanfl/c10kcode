#!/bin/sh

# Installs the built omniorb from $PLAT/omni into /opt/omniorb3/$PLAT,
# and makes a symlink to there from /opt/omniorb3/native.
# (You'll probably need root to run this.)
# (omni-orb should already have been unpacked and "make export"ed in $PLAT)
# FIXME currently relies on Python 2.1 for installing site-packages
#
# Steven Mueller, 2001-12-18
set -xe

PLAT=i586_linux_2.0_glibc2.1
OMNIBASEDIR=/opt/omniorb3
INSTALL_DIR=$OMNIBASEDIR/$PLAT
INSTALL_LOG=omni-install.log

# Prefix location for things like manpages
PREFIX=/usr/local
PYMODULES_DIR=/usr/local/lib/python2.1/site-packages

mkdir -p $INSTALL_DIR
# Log our installation steps to ease removal
exec >> $INSTALL_LOG

cd $PLAT/omni
date

# Create symlink from native
rm -rf $OMNIBASEDIR/native
ln -s $PLAT $OMNIBASEDIR/native

# Install everything but source into INSTALL_DIR
cp -va `find * -maxdepth 0 -not -name src` $INSTALL_DIR

mkdir -p $INSTALL_DIR/src
# Install the examples
cp -va src/examples $INSTALL_DIR/src

# Install the python modules
cp -va lib/python/* $PYMODULES_DIR

# Install manpages
cp -va man/* $PREFIX/man

# Uncomment the folling cp lines for a more seemlessly integrated installation
# (Note: this has not been tested.  You may also need to add /usr/local/lib to
# your /etc/ld.so.conf)
# Install the binaries, libraries, and includes
#cp -va bin/$PLAT/* $PREFIX/bin
#cp -va lib/$PLAT/* $PREFIX/lib
#cp -va include $PREFIX/include
