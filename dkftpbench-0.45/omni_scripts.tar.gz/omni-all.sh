#!/bin/sh

# Downloads, builds, and installs omniorb 3 for the i586 architecture and then
# for the ppc405 architecture.  sudo must be installed and configured properly
# for the user running this script.  Python must also be installed and in the
# path, or you will need to edit the OPTS variable in each relevant script.
#
# Also builds the 2nd echo example client and servant in the current
# directory.
#
# Steven Mueller, 2001-12-18
set -xe

PLAT=i586_linux_2.0_glibc2.1
CROSS_PLAT=405_linux_2.0_glibc2.1
OPTS="platform=$PLAT PYTHON=`which python`"

# Download the current (as of Dec 14, 2001) omniorb source distro
if [ ! -f omniORB_304.tar.gz ]; then
    wget ftp://ftp.uk.research.att.com/pub/omniORB/omniORB3/omniORB_304.tar.gz
fi

mkdir -p $PLAT
cd $PLAT
rm -rf omni
tar -xzvf ../omniORB_304.tar.gz
cd ..

# Build and install omniorb for the native (host) platform
/bin/sh ./omni-build.sh
sudo /bin/sh ./omni-install.sh

# Unpack a seperate sourcetree for the target platform
# (extra paranoia for peace of mind!)
mkdir -p $CROSS_PLAT
cd $CROSS_PLAT
rm -rf omni
tar -xzvf ../omniORB_304.tar.gz

# Fix up a few unhappy dir.mk files
patch -p0 < ../omni-libcxxoptions.patch
cd ..

# Build and install omniorb for the ppc 405 target platform
/bin/sh ./omni-build-405.sh
sudo /bin/sh ./omni-install-405.sh

# Build the native and ppc 405 versions of the echo 2nd example
/bin/sh ./omni-echo-build.sh native
/bin/sh ./omni-echo-build.sh cross

# Create the support tarball
/bin/sh ./omni-support.sh

echo "Installation succesful!  See README.ppc405 for more fun things to try."
