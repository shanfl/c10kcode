#!/bin/sh

# Builds omniorb 3 for the IBM PowerPC 405.
# Assumes the omniorb sources have been unpacked into
# $PLAT under the current directory.  Copies over 405_linux_2.0_glibc2.1.mk
# into omn/mk/platforms first.
#
# Steven Mueller, 2001-12-18
set -xe

PLAT=405_linux_2.0_glibc2.1
#PLAT=i586_linux_2.0_glibc2.1
OPTS="platform=$PLAT PYTHON=`which python` CROSS_CFLAGS=-mcpu=403"

# Install the cross-compiling platformer makefile
cp $PLAT.mk $PLAT/omni/mk/platforms

cd $PLAT/omni/src
make export $OPTS
