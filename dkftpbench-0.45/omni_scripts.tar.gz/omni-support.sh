#!/bin/sh
set -ex

# Create a secondary fsimg tarball containing various supporting libraries and
# binaries for running omniorb applications.  Transfer the tarball to the pcpu
# and untar it into the root director to play:
#
# / # tar zxvf omnisupport.tar.gz
#
# FIXME what a kludge!  Maybe we should source defs.sh to get the paths and
# stuff while we're at it.
# TODO add omniNames
# (yoinked Dan's lib copying stuff from prepfsimg-nonroot.sh)


PLAT=405_linux_2.0_glibc2.1
OMNIBASEDIR=/opt/omniorb3
# Base dir of target binaries and libraries
#targetdir=$IXIA_GCC3_TARGET_LIB/..
targetdir=/opt/hardhat/devkit/ppc/405/target
OMNILIBDIR=$OMNIBASEDIR/$PLAT/lib/$PLAT
CROSS_TOOL_PREFIX=/opt/hardhat/devkit/ppc/405/bin/powerpc-linux-
#CROSS_TOOL_PREFIX=${IXIA_CROSS_TOOL}

TARBALL=omnisupport.tar.gz
OMNISTAGING=`pwd`/omnisupport-staging

rm -rf "$OMNISTAGING"
mkdir -p "$OMNISTAGING"

# Copy a few more shlibs to the image dir tree (but no static ones)
FILTER=/tmp/filter.$USER.$$.tmp
> $FILTER
# We don't need libnss_dns or libresolv as long as host.conf and nsswitch.conf
# don't reference dns or bind...
for lib in libnss_files; do
	echo "/$lib[-\.]" >> $FILTER
done
cd $targetdir
find lib -name '*.so*' -print | egrep -f $FILTER | cpio -pdmv "$OMNISTAGING"
if [ -d usr/lib ]; then
	find usr/lib -name '*.so*' -print | egrep -f $FILTER | cpio -pdmv "$OMNISTAGING"
fi
rm $FILTER

# Add in the 3 needed omni orb libraries for the echo example
FILTER=/tmp/filter.$USER.$$.tmp
> $FILTER
for lib in libomniORB3 libomnithread libtcpwrapGK; do
	echo "/$lib[-\.]" >> $FILTER
done
cd $OMNILIBDIR
find . -name '*.so*' -print | egrep -f $FILTER | cpio -pdmv "$OMNISTAGING"/lib
rm $FILTER


cd "$OMNISTAGING"
# strip the libraries
strip=${CROSS_TOOL_PREFIX}strip
find . -name "*.so" | xargs $strip

# put some other stuff in, too
mkdir -p bin
cp $targetdir/usr/bin/strace bin

# And set up some network configuration to be less reliant on nss
mkdir -p etc
cat > etc/resolv.conf << EORESOLV
EORESOLV
cat > etc/nsswitch.conf << EONSSWITCH
hosts:          files
networks:       files
protocols:      files
services:       files
EONSSWITCH
cat > etc/host.conf << EOHOSTCONF
order hosts
multi on
EOHOSTCONF
cat > etc/hosts << EOHOSTS
127.0.0.1	localhost
192.168.3.117	dank
192.168.3.118	chassis
192.168.6.39	dank2
EOHOSTS
cat > etc/hostname << EOHOSTNAME
pcpu1
EOHOSTNAME

# tarball it
tar zcvf ../$TARBALL *
