#!/bin/sh

# Builds omniorb 3.  Assumes the omniorb sources have been unpacked into
# $PLAT under the current directory.
#
# Steven Mueller, 2001-12-18
set -xe

PLAT=i586_linux_2.0_glibc2.1
OPTS="platform=$PLAT PYTHON=`which python`"

cd $PLAT/omni/src
make export $OPTS
