#!/bin/sh

# Installs the cross-compiled omniorb from $PLAT/omni into /opt/omniorb3/$PLAT.
# (You'll probably need root to run this.)
# (omni-orb should already have been unpacked and "make export"ed in $PLAT)
#
# Steven Mueller, 2001-12-18
set -xe

PLAT=405_linux_2.0_glibc2.1
OMNIBASEDIR=/opt/omniorb3
INSTALL_DIR=$OMNIBASEDIR/$PLAT

mkdir -p $INSTALL_DIR

cd $PLAT/omni

# Install everything but source into INSTALL_DIR
cp -va `find * -maxdepth 0 -not -name src` $INSTALL_DIR
